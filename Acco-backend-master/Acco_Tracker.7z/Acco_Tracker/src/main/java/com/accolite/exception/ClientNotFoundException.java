package com.accolite.exception;

public class ClientNotFoundException extends Exception{
    
}
